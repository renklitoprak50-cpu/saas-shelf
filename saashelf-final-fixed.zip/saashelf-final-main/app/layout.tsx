import React from 'react';
import '../src/index.css';

export const metadata = {
  title: 'SaaShelf | Premium Micro-SaaS & Startup Marketplace',
  description: 'SaaShelf is a curated marketplace to buy and acquire premium high-yield digital assets, Micro-SaaS projects, and Web platforms with safe affiliate tracking.',
  keywords: 'buy saas, acquire startup, buy newsletter, micro saas platform, digital assets, saashelf, trustmrr, flippa',
};

export const viewport = {
  width: 'device-width',
  initialScale: 1.0,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        {/* Google Fonts injection matching current index.html */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap" 
          rel="stylesheet" 
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              // Prevent browser extensions from crashing the application with Web3 injection errors
              window.addEventListener('error', function(e) {
                if (e.message && (e.message.indexOf('ethereum') !== -1 || e.message.indexOf('redefine property') !== -1)) {
                  e.stopImmediatePropagation();
                  e.preventDefault();
                  return true;
                }
              }, true);
            `,
          }}
        />
      </head>
      <body className="bg-slate-50 text-slate-800 antialiased overflow-x-hidden">
        <div id="root">{children}</div>
      </body>
    </html>
  );
}
