-- Database Schema for SaaShelf
-- This script contains the table structure for PostgreSQL, designed to run in Supabase, Neon, or standard PostgreSQL RDS instances.

-- 1. Create a platform tracking ENUM or type if desired, or use standard varchar constraints.
CREATE TABLE IF NOT EXISTS startup_listings (
    id SERIAL PRIMARY KEY,
    startup_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    short_description TEXT NOT NULL,
    revenue_30d VARCHAR(50) NOT NULL,          -- e.g., "$6.2k"
    asking_price VARCHAR(50) NOT NULL,         -- e.g., "$130k"
    multiple VARCHAR(20) NOT NULL,             -- e.g., "1.7x"
    source_platform VARCHAR(100) DEFAULT 'trustmrr' NOT NULL, -- e.g. 'trustmrr', 'flippa', 'empireflippers'
    original_url TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Indexing for fast search & filtering of platform, categories, and price ranges.
CREATE INDEX IF NOT EXISTS idx_listings_platform ON startup_listings(source_platform);
CREATE INDEX IF NOT EXISTS idx_listings_category ON startup_listings(category);
