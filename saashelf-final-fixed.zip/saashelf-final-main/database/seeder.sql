-- SQL Seeder Script for SaaShelf Premium Listings
-- This script inserts premium listings sourced from TrustMRR (priced >= $10,000)

INSERT INTO startup_listings (
  startup_name, 
  category, 
  short_description, 
  revenue_30d, 
  asking_price, 
  multiple, 
  source_platform, 
  original_url
) VALUES
(
  'Outstand.so',
  'Developer Tools',
  'Unified social media API - the only usage-based pricing API in this market. For developers, agents and content management automations.',
  '$6.2k',
  '$130k',
  '1.7x',
  'trustmrr',
  'https://trustmrr.com/startup/outstand-so'
),
(
  'Backlinker AI',
  'Marketing',
  'Backlinker AI automates backlink acquisition through AI-powered reporter and editorial outreach. Built for agencies, founders, and SEO teams.',
  '$23k',
  '$350k',
  '1.3x',
  'trustmrr',
  'https://trustmrr.com/startup/backlinker-ai'
),
(
  'NextjobConnect LLC',
  'SaaS',
  'Real-time job leads for home service contractors. Monitors neighborhood platforms, AI-classifies posts by trade, and alerts subscribers.',
  '$5.8k',
  '$100k',
  '1.4x',
  'trustmrr',
  'https://trustmrr.com/startup/nextjobconnect-llc'
),
(
  'Atlas',
  'Artificial Intelligence',
  'Atlas is a personalized learning platform for students. Atlas''s AI studies your class materials to help you nail your homework and ace your tests.',
  '$22k',
  '$1.3M',
  '4.7x',
  'trustmrr',
  'https://trustmrr.com/startup/atlas'
),
(
  'Fiddl.art',
  'Content Creation',
  'Fiddl.art is a creative platform for high quality AI images and videos using models like Nano Banana Pro, Flux 2 and Sora.',
  '$28k',
  '$1.1M',
  '3.4x',
  'trustmrr',
  'https://trustmrr.com/startup/fiddl-art'
),
(
  'Chatwith',
  'Customer Support',
  'AI chatbots for agencies. Trained on website & files, fully white labeled, and with AI tool use.',
  '$4.2k',
  '$147k',
  '2.9x',
  'trustmrr',
  'https://trustmrr.com/startup/chatwith'
),
(
  'POST BRIDGE',
  'Social Media',
  'Post your content to multiple social media platforms at the same time, all-in one place.',
  '$41k',
  '$4.2M',
  '8.6x',
  'trustmrr',
  'https://trustmrr.com/startup/post-bridge'
),
(
  'VoiceType.com',
  'Artificial Intelligence',
  'VoiceType is an AI-driven voice dictation software designed to increase productivity by replacing typing with speech.',
  '$6.5k',
  '$219k',
  '2.8x',
  'trustmrr',
  'https://trustmrr.com/startup/voicetype-com'
),
(
  'RunAds.ai',
  'Marketing',
  'Fully autonomous AI google ads agent for all businesses! Ecommerce, lead gen, retail, local service based!',
  '$11k',
  '$200k',
  '1.5x',
  'trustmrr',
  'https://trustmrr.com/startup/runads-ai'
);
